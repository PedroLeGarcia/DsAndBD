﻿namespace ProjetoBD2
{


    partial class CadastroDataSet
    {
    }
}

namespace ProjetoBD2.CadastroDataSetTableAdapters
{
    partial class tbFornecedorTableAdapter
    {
    }

    public partial class tbUsuarioTableAdapter {
    }
}
